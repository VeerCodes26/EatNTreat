/**
 * ============================================================================
 * KREO KEYBOARD AUDIO SYNTHESIZER ENGINE (Web Audio API)
 * Procedural Mechanical Switch Acoustics + Realtime Visualizer + ASMR Lounge
 * ============================================================================
 */

class KreoAudioEngine {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.analyser = null;
    this.isMuted = false;
    this.currentProfile = 'creamy';
    
    // Lo-Fi & ASMR Mood Lounge nodes
    this.rainNode = null;
    this.rainGain = null;
    this.lofiInterval = null;
    this.lofiGain = null;
    
    this.initialized = false;
  }

  init() {
    if (this.initialized) return;
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AudioContext();
      
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = 0.85;

      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 64;
      this.analyser.smoothingTimeConstant = 0.8;

      this.masterGain.connect(this.analyser);
      this.analyser.connect(this.ctx.destination);

      this.initialized = true;
    } catch (e) {
      console.warn("Web Audio API not supported or blocked:", e);
    }
  }

  ensureAudio() {
    if (!this.initialized) this.init();
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  setProfile(profile) {
    this.currentProfile = profile;
  }

  setMuted(muted) {
    this.isMuted = muted;
    if (this.masterGain) {
      this.masterGain.gain.setValueAtTime(muted ? 0 : 0.85, this.ctx.currentTime);
    }
  }

  setMasterVolume(val) {
    if (this.masterGain && !this.isMuted) {
      this.masterGain.gain.setValueAtTime(val, this.ctx.currentTime);
    }
  }

  /**
   * Play procedural keystroke sound based on current profile and key type
   */
  playKey(keyCode = 0, isSpace = false, isMod = false) {
    if (this.isMuted) return;
    this.ensureAudio();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    // Small random pitch variation for organic tactile reality
    const pitchVariation = (Math.random() * 0.12) - 0.06;

    switch (this.currentProfile) {
      case 'creamy':
        this._playCreamy(t, pitchVariation, isSpace, isMod);
        break;
      case 'thocky':
        this._playThocky(t, pitchVariation, isSpace, isMod);
        break;
      case 'clicky':
        this._playClicky(t, pitchVariation, isSpace, isMod);
        break;
      case 'silent':
        this._playSilent(t, pitchVariation, isSpace, isMod);
        break;
      case 'synth':
        this._playSynth(t, keyCode);
        break;
      default:
        this._playCreamy(t, pitchVariation, isSpace, isMod);
    }
  }

  /**
   * 1. CREAMY BUTTER (Lubed Linear Gateron Oil Kings)
   * Deep, smooth, marble-like low-pass acoustic pop with body resonance
   */
  _playCreamy(t, varPitch, isSpace, isMod) {
    const baseFreq = isSpace ? 140 : (isMod ? 180 : 220);
    const freq = baseFreq * (1 + varPitch);

    // 1. Initial buttery bottom-out pop (Triangle)
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq * 1.8, t);
    osc.frequency.exponentialRampToValueAtTime(freq * 0.4, t + 0.05);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(800, t);
    filter.frequency.exponentialRampToValueAtTime(150, t + 0.06);

    gain.gain.setValueAtTime(0.7, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.055);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + 0.06);

    // 2. Wooden switch housing body resonance
    const bodyOsc = this.ctx.createOscillator();
    const bodyGain = this.ctx.createGain();
    bodyOsc.type = 'sine';
    bodyOsc.frequency.setValueAtTime(freq * 0.75, t);
    bodyOsc.frequency.exponentialRampToValueAtTime(freq * 0.3, t + 0.07);

    bodyGain.gain.setValueAtTime(isSpace ? 0.9 : 0.5, t);
    bodyGain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);

    bodyOsc.connect(bodyGain);
    bodyGain.connect(this.masterGain);

    bodyOsc.start(t);
    bodyOsc.stop(t + 0.085);
  }

  /**
   * 2. HOLY PANDA THOCK (Deep Tactile Marble Snap)
   * Punchy tactile bump transient + resonant hollow marble clack
   */
  _playThocky(t, varPitch, isSpace, isMod) {
    const baseFreq = isSpace ? 160 : (isMod ? 210 : 260);
    const freq = baseFreq * (1 + varPitch);

    // Tactile snap transient (Bandpass Noise)
    const bufferSize = this.ctx.sampleRate * 0.02;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.3));
    }
    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const noiseFilter = this.ctx.createBiquadFilter();
    noiseFilter.type = 'bandpass';
    noiseFilter.frequency.value = 1400;
    noiseFilter.Q.value = 3;

    const noiseGain = this.ctx.createGain();
    noiseGain.gain.setValueAtTime(0.6, t);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, t + 0.03);

    noise.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(this.masterGain);

    noise.start(t);

    // Deep marble bottom out
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq * 2.2, t);
    osc.frequency.exponentialRampToValueAtTime(freq * 0.5, t + 0.07);

    gain.gain.setValueAtTime(0.8, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.07);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + 0.075);
  }

  /**
   * 3. CRISP BLUE CLICKY (Sharp Tactile Blue Snap)
   * High-frequency metallic leaf click + crisp snappy switch reset
   */
  _playClicky(t, varPitch, isSpace, isMod) {
    // High frequency metallic click
    const clickOsc = this.ctx.createOscillator();
    const clickGain = this.ctx.createGain();
    clickOsc.type = 'triangle';
    clickOsc.frequency.setValueAtTime(3200 * (1 + varPitch), t);
    clickOsc.frequency.exponentialRampToValueAtTime(1200, t + 0.015);

    clickGain.gain.setValueAtTime(0.85, t);
    clickGain.gain.exponentialRampToValueAtTime(0.001, t + 0.02);

    clickOsc.connect(clickGain);
    clickGain.connect(this.masterGain);

    clickOsc.start(t);
    clickOsc.stop(t + 0.025);

    // Follow-up bottom out
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(isSpace ? 280 : 380, t + 0.005);
    osc.frequency.exponentialRampToValueAtTime(100, t + 0.04);

    gain.gain.setValueAtTime(0.4, t + 0.005);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.04);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t + 0.005);
    osc.stop(t + 0.045);
  }

  /**
   * 4. SILENT VELVET (Muted Silicone ASMR Dampening)
   * Super soft, low amplitude cushioned tap
   */
  _playSilent(t, varPitch, isSpace, isMod) {
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();

    osc.type = 'sine';
    osc.frequency.setValueAtTime((isSpace ? 110 : 150) * (1 + varPitch), t);
    osc.frequency.exponentialRampToValueAtTime(60, t + 0.04);

    filter.type = 'lowpass';
    filter.frequency.value = 220;

    gain.gain.setValueAtTime(0.35, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.035);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + 0.04);
  }

  /**
   * 5. 8-BIT CYBER SYNTH
   * Retro chiptune synthesizer tones mapped across key code frequencies
   */
  _playSynth(t, keyCode) {
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    // Pentatonic scale mapping
    const pentatonic = [261.63, 293.66, 329.63, 392.00, 440.00, 523.25, 587.33, 659.25, 783.99, 880.00];
    const note = pentatonic[(keyCode || 65) % pentatonic.length];

    osc.type = 'square';
    osc.frequency.setValueAtTime(note, t);

    gain.gain.setValueAtTime(0.2, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + 0.13);
  }

  /**
   * Haptic tick sound when turning the Kreo Rotary Knob
   */
  playKnobTick() {
    if (this.isMuted) return;
    this.ensureAudio();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(1800, t);
    osc.frequency.exponentialRampToValueAtTime(400, t + 0.012);

    gain.gain.setValueAtTime(0.3, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.015);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + 0.018);
  }

  /**
   * ASMR Mood Lounge: Procedural Rain Generator
   */
  toggleRain(enable, volume = 0.4) {
    this.ensureAudio();
    if (!this.ctx) return false;

    if (!enable && this.rainNode) {
      this.rainGain.gain.linearRampToValueAtTime(0.001, this.ctx.currentTime + 0.5);
      setTimeout(() => {
        if (this.rainNode) {
          this.rainNode.stop();
          this.rainNode.disconnect();
          this.rainNode = null;
        }
      }, 600);
      return false;
    }

    if (enable && !this.rainNode) {
      const bufferSize = this.ctx.sampleRate * 2;
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }

      this.rainNode = this.ctx.createBufferSource();
      this.rainNode.buffer = buffer;
      this.rainNode.loop = true;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.value = 800;
      filter.Q.value = 0.6;

      this.rainGain = this.ctx.createGain();
      this.rainGain.gain.setValueAtTime(0.001, this.ctx.currentTime);
      this.rainGain.gain.linearRampToValueAtTime(volume * 0.35, this.ctx.currentTime + 1.0);

      this.rainNode.connect(filter);
      filter.connect(this.rainGain);
      this.rainGain.connect(this.masterGain);

      this.rainNode.start();
      return true;
    }
    return enable;
  }

  /**
   * ASMR Mood Lounge: Procedural Lo-Fi Chords
   */
  toggleLoFi(enable, volume = 0.4) {
    this.ensureAudio();
    if (!this.ctx) return false;

    if (!enable && this.lofiInterval) {
      clearInterval(this.lofiInterval);
      this.lofiInterval = null;
      return false;
    }

    if (enable && !this.lofiInterval) {
      const chords = [
        [261.63, 329.63, 392.00, 493.88], // Cmaj7
        [220.00, 261.63, 329.63, 392.00], // Am7
        [174.61, 220.00, 261.63, 329.63], // Fmaj7
        [196.00, 246.94, 293.66, 349.23]  // G7
      ];
      let chordIndex = 0;

      const playChord = () => {
        if (!this.ctx || this.isMuted) return;
        const currentChord = chords[chordIndex % chords.length];
        chordIndex++;
        const t = this.ctx.currentTime;

        currentChord.forEach((freq, idx) => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          const filter = this.ctx.createBiquadFilter();

          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, t);

          filter.type = 'lowpass';
          filter.frequency.setValueAtTime(450 + idx * 50, t);

          gain.gain.setValueAtTime(0.001, t);
          gain.gain.linearRampToValueAtTime(volume * 0.12, t + 0.8);
          gain.gain.exponentialRampToValueAtTime(0.0001, t + 3.8);

          osc.connect(filter);
          filter.connect(gain);
          gain.connect(this.masterGain);

          osc.start(t);
          osc.stop(t + 4.0);
        });
      };

      playChord();
      this.lofiInterval = setInterval(playChord, 4000);
      return true;
    }
    return enable;
  }
}

// Global audio engine singleton
window.kreoAudio = new KreoAudioEngine();
