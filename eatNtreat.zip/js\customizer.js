/**
 * ============================================================================
 * KREO CUSTOMIZER & LIGHTING STUDIO ENGINE
 * RGB Matrix Modes • Switch Profile Selection • Sliders • LED Matrix Canvas
 * ============================================================================
 */

class KreoCustomizerStudio {
  constructor() {
    this.ledCanvas = document.getElementById('led-matrix-canvas');
    this.ledCtx = this.ledCanvas ? this.ledCanvas.getContext('2d') : null;
    this.init();
  }

  init() {
    this.bindLightingControls();
    this.bindSwitchControls();
    this.initLedMatrix();
  }

  bindLightingControls() {
    // RGB Preset Cards
    const presetCards = document.querySelectorAll('.rgb-preset-card');
    presetCards.forEach(card => {
      card.addEventListener('click', () => {
        presetCards.forEach(c => c.classList.remove('active'));
        card.classList.add('active');

        const effect = card.dataset.effect;
        if (window.kreoKeyboard) {
          window.kreoKeyboard.setRgbMode(effect);
        }

        // Sync dropdown
        const rgbSelect = document.getElementById('rgb-mode-select');
        if (rgbSelect) rgbSelect.value = effect;
      });
    });

    // RGB dropdown on Home stage
    const rgbSelect = document.getElementById('rgb-mode-select');
    if (rgbSelect) {
      rgbSelect.addEventListener('change', (e) => {
        const effect = e.target.value;
        if (window.kreoKeyboard) {
          window.kreoKeyboard.setRgbMode(effect);
        }
        presetCards.forEach(c => {
          c.classList.toggle('active', c.dataset.effect === effect);
        });
      });
    }

    // Color Swatches
    const swatches = document.querySelectorAll('.color-swatch');
    swatches.forEach(swatch => {
      swatch.addEventListener('click', () => {
        swatches.forEach(s => s.classList.remove('active'));
        swatch.classList.add('active');
        const color = swatch.dataset.color;
        if (window.kreoKeyboard) {
          window.kreoKeyboard.setRgbColor(color);
        }
      });
    });

    // Brightness Slider
    const bSlider = document.getElementById('slider-brightness');
    const bVal = document.getElementById('val-brightness');
    if (bSlider) {
      bSlider.addEventListener('input', (e) => {
        const val = e.target.value;
        if (bVal) bVal.textContent = `${val}%`;
        if (window.kreoKeyboard) {
          window.kreoKeyboard.setBrightness(val / 100);
        }
      });
    }

    // Halo Glow Slider
    const haloSlider = document.getElementById('slider-halo');
    const haloVal = document.getElementById('val-halo');
    if (haloSlider) {
      haloSlider.addEventListener('input', (e) => {
        const val = e.target.value;
        if (haloVal) haloVal.textContent = `${val}%`;
        const aura = document.getElementById('keyboard-ambient-aura');
        if (aura) aura.style.opacity = (val / 100).toString();
      });
    }
  }

  bindSwitchControls() {
    const switchCards = document.querySelectorAll('.switch-sound-card');
    const switchSelect = document.getElementById('switch-sound-select');

    const updateProfile = (profile) => {
      if (window.kreoAudio) {
        window.kreoAudio.setProfile(profile);
      }
      switchCards.forEach(c => {
        c.classList.toggle('active', c.dataset.switch === profile);
      });
      if (switchSelect) switchSelect.value = profile;

      // Update table display
      const tableSwitch = document.getElementById('table-user-switch');
      if (tableSwitch) {
        const names = {
          creamy: 'Creamy Butter (Lubed)',
          thocky: 'Holy Panda Thock',
          clicky: 'Crisp Blue Snap',
          silent: 'Silent Velvet ASMR',
          synth: '8-Bit Cyber Synth'
        };
        tableSwitch.textContent = names[profile] || profile;
      }
    };

    switchCards.forEach(card => {
      card.addEventListener('click', (e) => {
        if (!e.target.closest('.test-sound-btn')) {
          updateProfile(card.dataset.switch);
        }
      });
    });

    // Sound test buttons
    const testBtns = document.querySelectorAll('.test-sound-btn');
    testBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const profile = btn.dataset.sound;
        updateProfile(profile);
        if (window.kreoAudio) {
          // Play a small satisfying 3-tap arpeggio
          window.kreoAudio.playKey(65, false, false);
          setTimeout(() => window.kreoAudio.playKey(66, false, false), 90);
          setTimeout(() => window.kreoAudio.playKey(32, true, false), 180);
        }
      });
    });

    if (switchSelect) {
      switchSelect.addEventListener('change', (e) => {
        updateProfile(e.target.value);
      });
    }
  }

  initLedMatrix() {
    if (!this.ledCanvas || !this.ledCtx) return;

    const cols = 24;
    const rows = 6;
    let tick = 0;

    const render = () => {
      tick += 0.04;
      const w = this.ledCanvas.width = this.ledCanvas.parentElement.clientWidth || 600;
      const h = this.ledCanvas.height = 120;

      this.ledCtx.fillStyle = '#090B12';
      this.ledCtx.fillRect(0, 0, w, h);

      const cellW = (w - 20) / cols;
      const cellH = (h - 20) / rows;

      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const x = 10 + c * cellW + cellW / 2;
          const y = 10 + r * cellH + cellH / 2;

          let hue = 270; // Purple base
          if (window.kreoKeyboard && window.kreoKeyboard.activeRgbMode === 'cyber-wave') {
            hue = (tick * 50 + c * 15 + r * 10) % 360;
          } else if (window.kreoKeyboard && window.kreoKeyboard.activeRgbMode === 'matrix-rain') {
            hue = 150;
          }

          const radius = 3.5;
          const glow = Math.sin(tick * 2 + (c + r) * 0.4) * 0.3 + 0.7;

          this.ledCtx.save();
          this.ledCtx.fillStyle = `hsl(${hue}, 90%, ${50 * glow}%)`;
          this.ledCtx.shadowBlur = 6 * glow;
          this.ledCtx.shadowColor = `hsl(${hue}, 90%, 60%)`;
          this.ledCtx.beginPath();
          this.ledCtx.arc(x, y, radius, 0, Math.PI * 2);
          this.ledCtx.fill();
          this.ledCtx.restore();
        }
      }

      requestAnimationFrame(render);
    };

    render();
  }
}

window.kreoCustomizer = new KreoCustomizerStudio();
