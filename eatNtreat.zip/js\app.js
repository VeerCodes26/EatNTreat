/**
 * ============================================================================
 * GOODFURS INDIA — MAIN PET SHOP & ADOPTION APPLICATION
 * Live Puppy Directory • Breed Matcher AI • Cart System • WhatsApp Inquiries
 * ============================================================================
 */

// Global Puppies Database (Matching Official GoodFurs Price Ranges)
window.puppiesData = [
  {
    id: 'pet-1',
    name: 'Snoopy',
    breed: 'Beagle',
    category: 'medium',
    gender: 'Male',
    age: '7 Weeks',
    price: 15000,
    priceFormatted: '₹15,000',
    image: 'https://images.unsplash.com/photo-1505628346881-b72b27e84530?w=600&auto=format&fit=crop&q=80',
    kci: true,
    location: 'Delhi NCR, Jaipur, Chandigarh',
    vacStatus: '1st DHPPIL Done',
    desc: 'Playful, gentle, and food-loving Beagle puppy. Microchipped with champion lineage.'
  },
  {
    id: 'pet-2',
    name: 'Bruno',
    breed: 'Labrador',
    category: 'large',
    gender: 'Male',
    age: '7 Weeks',
    price: 12000,
    priceFormatted: '₹12,000',
    image: 'https://images.unsplash.com/photo-1591769225440-811ad7d6eab2?w=600&auto=format&fit=crop&q=80',
    kci: true,
    location: 'All India Transit Available',
    vacStatus: '1st Dose Done',
    desc: 'Heavy-bone Golden Yellow Labrador with calm, obedient, kid-friendly temperament.'
  },
  {
    id: 'pet-3',
    name: 'Mochi',
    breed: 'Shih-Tzu',
    category: 'small',
    gender: 'Female',
    age: '7 Weeks',
    price: 18000,
    priceFormatted: '₹18,000',
    image: 'https://images.unsplash.com/photo-1583337130417-3346a1be7dee?w=600&auto=format&fit=crop&q=80',
    kci: false,
    location: 'Delhi NCR, Mumbai, Pune',
    vacStatus: '1st Dose & Dewormed',
    desc: 'Ultra-cute, non-shedding tri-color Shih-Tzu girl. Ideal for compact apartment living.'
  },
  {
    id: 'pet-4',
    name: 'Milo',
    breed: 'Golden Retriever',
    category: 'large',
    gender: 'Male',
    age: '8 Weeks',
    price: 22000,
    priceFormatted: '₹22,000',
    image: 'https://images.unsplash.com/photo-1633722715463-d30f4f325e24?w=600&auto=format&fit=crop&q=80',
    kci: true,
    location: 'Delhi NCR, Jaipur, Chandigarh',
    vacStatus: '1st Dose Done',
    desc: 'Fluffy cream Golden Retriever with loving personality and imported bloodline.'
  },
  {
    id: 'pet-5',
    name: 'Rex',
    breed: 'Siberian Husky',
    category: 'large',
    gender: 'Male',
    age: '8 Weeks',
    price: 25000,
    priceFormatted: '₹25,000',
    image: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=600&auto=format&fit=crop&q=80',
    kci: true,
    location: 'Delhi NCR, Mumbai, Bangalore',
    vacStatus: '1st & 2nd Dose Done',
    desc: 'Stunning bi-eyed Siberian Husky with striking coat and energetic, vocal personality.'
  },
  {
    id: 'pet-6',
    name: 'Oscar',
    breed: 'Pug',
    category: 'small',
    gender: 'Male',
    age: '7 Weeks',
    price: 10000,
    priceFormatted: '₹10,000',
    image: 'https://images.unsplash.com/photo-1517849845537-4d257902454a?w=600&auto=format&fit=crop&q=80',
    kci: false,
    location: 'Delhi NCR, Bangalore, Pune',
    vacStatus: '1st Dose & Dewormed',
    desc: 'Adorable fawn Pug puppy with gentle, low-maintenance indoor temperament.'
  },
  {
    id: 'pet-7',
    name: 'Rocky',
    breed: 'German Shepherd',
    category: 'large',
    gender: 'Male',
    age: '8 Weeks',
    price: 20000,
    priceFormatted: '₹20,000',
    image: 'https://images.unsplash.com/photo-1589941013453-ec89f33b5e95?w=600&auto=format&fit=crop&q=80',
    kci: true,
    location: 'Delhi NCR, Mumbai, Chandigarh',
    vacStatus: '1st Dose Done & Microchipped',
    desc: 'Heavy-coat, double-boned German Shepherd puppy with loyal guarding instincts.'
  },
  {
    id: 'pet-8',
    name: 'Bella',
    breed: 'Poodle',
    category: 'small',
    gender: 'Female',
    age: '8 Weeks',
    price: 35000,
    priceFormatted: '₹35,000',
    image: 'https://images.unsplash.com/photo-1604848698030-c434ba08ece1?w=600&auto=format&fit=crop&q=80',
    kci: true,
    location: 'Delhi NCR, Bangalore, Mumbai',
    vacStatus: '1st Dose & Dewormed',
    desc: 'Hypoallergenic apricot Toy Poodle. Highly intelligent, eager to learn, and non-shedding.'
  }
];

// Shopping Cart Store
window.shopCart = [];

window.addToCart = function(name, price, image) {
  const existing = window.shopCart.find(i => i.name === name);
  if (existing) {
    existing.qty += 1;
  } else {
    window.shopCart.push({ name, price, image, qty: 1 });
  }

  updateCartUI();

  const drawer = document.getElementById('cart-drawer-modal');
  if (drawer) drawer.classList.add('active');

  if (typeof confetti === 'function') {
    confetti({ particleCount: 40, spread: 60, origin: { y: 0.8 } });
  }
};

window.removeFromCart = function(index) {
  window.shopCart.splice(index, 1);
  updateCartUI();
};

function updateCartUI() {
  const container = document.getElementById('cart-items-container');
  const countBadge = document.getElementById('cart-item-count');
  const totalVal = document.getElementById('cart-total-val');

  let totalItems = 0;
  let totalPrice = 0;

  window.shopCart.forEach(i => {
    totalItems += i.qty;
    totalPrice += i.price * i.qty;
  });

  if (countBadge) countBadge.textContent = totalItems;
  if (totalVal) totalVal.textContent = `₹${totalPrice.toLocaleString('en-IN')}`;

  if (container) {
    if (window.shopCart.length === 0) {
      container.innerHTML = `
        <div class="cart-empty-text">
          <i data-lucide="shopping-bag"></i>
          <p>Your pet care cart is empty.</p>
          <span>Select starter food or accessories to begin!</span>
        </div>
      `;
    } else {
      container.innerHTML = '';
      window.shopCart.forEach((item, idx) => {
        const row = document.createElement('div');
        row.className = 'cart-item-row';
        row.innerHTML = `
          <img src="${item.image}" alt="${item.name}" class="cart-item-thumb">
          <div class="cart-item-info" style="flex: 1;">
            <h5>${item.name}</h5>
            <span class="cart-item-p">₹${item.price.toLocaleString('en-IN')} × ${item.qty}</span>
          </div>
          <button style="background:transparent; border:none; color:#94A3B8; cursor:pointer; padding:6px;" onclick="removeFromCart(${idx})" title="Remove">
            <i data-lucide="trash-2"></i>
          </button>
        `;
        container.appendChild(row);
      });
    }

    if (window.lucide) window.lucide.createIcons();
  }
}

// Wishlist Store
window.petWishlist = new Set();

window.toggleWishlist = function(petId, name) {
  const isWishlisted = window.petWishlist.has(petId);
  if (isWishlisted) {
    window.petWishlist.delete(petId);
    showToast(`Removed ${name} from your Wishlist`);
  } else {
    window.petWishlist.add(petId);
    showToast(`❤️ Added ${name} to your Wishlist!`);
    if (typeof confetti === 'function') {
      confetti({ particleCount: 30, spread: 50, origin: { y: 0.7 } });
    }
  }
  const activeTab = document.querySelector('.filter-tab-pill.active')?.dataset.category || 'all';
  const searchVal = document.getElementById('global-pet-search')?.value || '';
  renderPuppiesGrid(activeTab, searchVal);
};

// Toast notification helper
function showToast(msg) {
  let toast = document.getElementById('goodfurs-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'goodfurs-toast';
    toast.style.cssText = `
      position: fixed;
      bottom: 24px;
      left: 50%;
      transform: translateX(-50%) translateY(100px);
      background: #0A1118;
      color: #FFFFFF;
      font-family: var(--font-body);
      font-size: 13px;
      font-weight: 700;
      padding: 12px 24px;
      border-radius: 999px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.3);
      border: 1px solid rgba(255, 107, 0, 0.4);
      z-index: 9999;
      transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
      display: flex;
      align-items: center;
      gap: 8px;
    `;
    document.body.appendChild(toast);
  }
  toast.innerHTML = `<span style="color:#FF6B00;">🐾</span> ${msg}`;
  toast.style.transform = 'translateX(-50%) translateY(0)';
  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => {
    toast.style.transform = 'translateX(-50%) translateY(100px)';
  }, 2600);
}

// Render Puppy Cards (Luxury E-commerce Cards)
function renderPuppiesGrid(filterCategory = 'all', searchQuery = '') {
  const container = document.getElementById('puppies-list-grid');
  if (!container) return;

  container.innerHTML = '';

  const filtered = window.puppiesData.filter(pet => {
    const matchesCat = (filterCategory === 'all') || 
                       (filterCategory === 'kci' ? pet.kci : pet.category === filterCategory);
    const matchesSearch = !searchQuery || 
                          pet.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          pet.breed.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          pet.location.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  if (filtered.length === 0) {
    container.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px; color: #64748B;">
        <i data-lucide="paw-print" style="width: 48px; height: 48px; margin-bottom: 12px; color: #FF6B00;"></i>
        <h3 style="font-family: var(--font-heading); color: #0A1118; font-size: 22px;">No puppies matched your search</h3>
        <p style="font-size: 14px;">Try searching for another breed like Beagle, Labrador, Husky, or Shih-Tzu.</p>
      </div>
    `;
    if (window.lucide) window.lucide.createIcons();
    return;
  }

  filtered.forEach(pet => {
    const isWishlisted = window.petWishlist.has(pet.id);
    const card = document.createElement('div');
    card.className = 'pet-card';
    card.innerHTML = `
      <div class="pet-card-img-wrap">
        <img src="${pet.image}" alt="${pet.name} ${pet.breed}" class="pet-card-img">
        ${pet.kci ? `<span class="pet-kci-badge"><i data-lucide="award"></i> KCI Registered</span>` : ''}
        
        <div style="position: absolute; top: 12px; right: 12px; display: flex; gap: 6px;">
          <button class="share-pet-btn" style="${isWishlisted ? 'color: #EF4444; background: #FFFFFF;' : ''}" onclick="toggleWishlist('${pet.id}', '${pet.name}')" title="Save to Wishlist">
            <i data-lucide="heart" style="${isWishlisted ? 'fill: #EF4444;' : ''}"></i>
          </button>
          <button class="share-pet-btn" onclick="sharePet('${pet.name}', '${pet.breed}')" title="Share Pet">
            <i data-lucide="share-2"></i>
          </button>
        </div>
      </div>
      <div class="pet-card-body">
        <div class="pet-card-header">
          <h3 class="pet-card-name">${pet.name}</h3>
          <span class="pet-card-price">${pet.priceFormatted}</span>
        </div>
        <div class="pet-meta-row">
          <span class="meta-tag">${pet.breed}</span>
          <span>•</span>
          <span>${pet.gender}</span>
          <span>•</span>
          <span>${pet.age}</span>
        </div>
        <div class="pet-cert-strip">
          <span class="cert-pill purebred"><i data-lucide="shield-check"></i> Purebred</span>
          <span class="cert-pill health"><i data-lucide="check"></i> 100% Health Checked</span>
        </div>
        <div class="pet-location-row">
          <i data-lucide="map-pin"></i>
          <span>${pet.location}</span>
        </div>
        <div class="pet-card-footer">
          <button class="meet-pet-btn" onclick="openPetModal('${pet.id}')">
            <i data-lucide="eye"></i>
            <span>Meet ${pet.name} (Live Video)</span>
          </button>
        </div>
      </div>
    `;
    container.appendChild(card);
  });

  if (window.lucide) window.lucide.createIcons();
}

// Global Breed Filter Helper
window.filterByBreedName = function(breedName) {
  const searchInput = document.getElementById('global-pet-search');
  if (searchInput) {
    searchInput.value = breedName;
    renderPuppiesGrid('all', breedName);
  }
  const section = document.getElementById('section-puppies');
  if (section) section.scrollIntoView({ behavior: 'smooth' });
};

// Open Pet Profile Modal
window.openPetModal = function(petId) {
  const pet = window.puppiesData.find(p => p.id === petId);
  if (!pet) return;

  const modal = document.getElementById('pet-details-modal');
  document.getElementById('modal-pet-img').src = pet.image;
  document.getElementById('modal-pet-name').textContent = pet.name;
  document.getElementById('modal-pet-breed').textContent = `${pet.breed} • ${pet.gender} • ${pet.age}`;
  document.getElementById('modal-pet-price').textContent = pet.priceFormatted;
  document.getElementById('modal-pet-age').textContent = pet.age;
  document.getElementById('modal-pet-gender').textContent = pet.gender;
  document.getElementById('modal-pet-vac').textContent = pet.vacStatus;
  document.getElementById('modal-pet-loc').textContent = pet.location;

  const kciPill = document.getElementById('modal-kci-pill');
  if (kciPill) {
    kciPill.style.display = pet.kci ? 'flex' : 'none';
  }

  // Hook Book / Inquire Button
  const bookBtn = document.getElementById('btn-book-pet');
  if (bookBtn) {
    bookBtn.onclick = () => {
      const city = document.getElementById('current-city-label')?.textContent || 'India';
      const msg = encodeURIComponent(`Hi eatNtreat India! I am interested in adopting ${pet.name} (${pet.breed}, ${pet.priceFormatted}) in ${city}. Please share live video call & vaccination certificate details.`);
      window.open(`https://wa.me/918779692292?text=${msg}`, '_blank');
    };
  }

  if (modal) modal.classList.add('active');
};

// Share Pet
window.sharePet = function(name, breed) {
  if (navigator.share) {
    navigator.share({
      title: `Adopt ${name} (${breed}) on eatNtreat`,
      text: `Check out ${name}, a purebred healthy ${breed} puppy available on eatNtreat India!`,
      url: window.location.href
    }).catch(() => {});
  } else {
    showToast(`Link copied! Check out ${name} (${breed}) on eatNtreat.`);
  }
};

// AI Breed Matcher Quiz Logic
window.quizAnswers = {};

window.selectQuizAnswer = function(step, val) {
  window.quizAnswers[step] = val;

  document.getElementById(`quiz-step-${step}`).classList.remove('active');

  if (step < 3) {
    document.getElementById(`quiz-step-${step + 1}`).classList.add('active');
  } else {
    calculateQuizMatch();
  }
};

function calculateQuizMatch() {
  const resultStep = document.getElementById('quiz-result-step');
  const title = document.getElementById('quiz-match-title');
  const desc = document.getElementById('quiz-match-desc');
  const viewBtn = document.getElementById('btn-view-matched-puppies');

  let matchBreed = 'Golden Retriever';
  let matchDesc = 'The ultimate family companion! Loving, patient with children, and highly intelligent.';

  if (window.quizAnswers[3] === 'hypoallergenic' || window.quizAnswers[1] === 'apartment') {
    if (window.quizAnswers[2] === 'calm') {
      matchBreed = 'Shih-Tzu';
      matchDesc = 'Fluffy, gentle, non-shedding, and loves curling up on the sofa. Perfect for flats.';
    } else {
      matchBreed = 'Poodle';
      matchDesc = 'Brilliant, non-shedding Toy Poodle! Extremely smart, clean, and full of playful energy.';
    }
  } else if (window.quizAnswers[3] === 'guard_dog') {
    matchBreed = 'Cane Corso';
    matchDesc = 'Majestic, brave, and deeply loyal. An outstanding protector for independent houses.';
  } else if (window.quizAnswers[2] === 'high') {
    matchBreed = 'Siberian Husky';
    matchDesc = 'Spirited, active, and breathtakingly gorgeous. Loves jogging and outdoor adventures.';
  } else if (window.quizAnswers[1] === 'apartment') {
    matchBreed = 'Beagle';
    matchDesc = 'Compact, friendly, and affectionate with big expressive eyes and a curious personality.';
  } else {
    matchBreed = 'Labrador';
    matchDesc = 'India’s most beloved dog! Gentle, loyal, easy to train, and deeply devoted to your family.';
  }

  if (title) title.textContent = matchBreed;
  if (desc) desc.textContent = matchDesc;
  if (resultStep) resultStep.classList.add('active');

  if (viewBtn) {
    viewBtn.onclick = () => {
      filterByBreedName(matchBreed);
    };
  }

  if (typeof confetti === 'function') {
    confetti({ particleCount: 70, spread: 80, origin: { y: 0.6 } });
  }
}

window.resetQuiz = function() {
  window.quizAnswers = {};
  document.querySelectorAll('.quiz-step').forEach(s => s.classList.remove('active'));
  document.getElementById('quiz-step-1').classList.add('active');
};

// DOM Init
document.addEventListener('DOMContentLoaded', () => {
  if (window.lucide) {
    window.lucide.createIcons();
  }

  // 1. Initial Render of Directory
  renderPuppiesGrid('all', '');

  // 2. Directory Filter Tabs
  const filterTabs = document.querySelectorAll('.filter-tab-pill');
  filterTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      filterTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const cat = tab.dataset.category;
      const searchVal = document.getElementById('global-pet-search')?.value || '';
      renderPuppiesGrid(cat, searchVal);
    });
  });

  // 3. Search Bar Live Filtering
  const searchInput = document.getElementById('global-pet-search');
  const searchBtn = document.getElementById('btn-search-trigger');

  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      const activeTab = document.querySelector('.filter-tab-pill.active')?.dataset.category || 'all';
      renderPuppiesGrid(activeTab, e.target.value);
    });
  }
  if (searchBtn && searchInput) {
    searchBtn.addEventListener('click', () => {
      const section = document.getElementById('section-puppies');
      if (section) section.scrollIntoView({ behavior: 'smooth' });
    });
  }

  // 4. City Location Dropdown
  const locBtn = document.getElementById('location-btn');
  const locMenu = document.getElementById('location-menu');
  const locLabel = document.getElementById('current-city-label');

  if (locBtn && locMenu) {
    locBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      locMenu.classList.toggle('active');
    });

    const options = locMenu.querySelectorAll('.loc-option');
    options.forEach(opt => {
      opt.addEventListener('click', () => {
        options.forEach(o => o.classList.remove('active'));
        opt.classList.add('active');
        const city = opt.dataset.city;
        if (locLabel) locLabel.textContent = city;
        locMenu.classList.remove('active');
      });
    });

    window.addEventListener('click', (e) => {
      if (!locMenu.contains(e.target) && e.target !== locBtn) {
        locMenu.classList.remove('active');
      }
    });
  }

  // 5. Cart Drawer Toggle & Checkout
  const cartToggleBtn = document.getElementById('btn-cart-toggle');
  const cartDrawer = document.getElementById('cart-drawer-modal');
  const closeCartBtn = document.getElementById('btn-close-cart');
  const checkoutBtn = document.getElementById('btn-checkout');

  if (cartToggleBtn && cartDrawer) {
    cartToggleBtn.addEventListener('click', () => {
      cartDrawer.classList.add('active');
    });
  }
  if (closeCartBtn && cartDrawer) {
    closeCartBtn.addEventListener('click', () => {
      cartDrawer.classList.remove('active');
    });
  }
  if (checkoutBtn) {
    checkoutBtn.addEventListener('click', () => {
      if (window.shopCart.length === 0) {
        alert("Your cart is empty. Please add pet food or accessories.");
        return;
      }
      if (typeof confetti === 'function') {
        confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
      }
      alert("🎉 Thank you! Your pet starter pack order has been placed. Our team will contact you for doorstep delivery.");
      window.shopCart = [];
      updateCartUI();
      if (cartDrawer) cartDrawer.classList.remove('active');
    });
  }

  // 6. Close Modal
  const petModal = document.getElementById('pet-details-modal');
  const closePetModalBtn = document.getElementById('btn-close-pet-modal');
  if (closePetModalBtn && petModal) {
    closePetModalBtn.addEventListener('click', () => {
      petModal.classList.remove('active');
    });
  }
  window.addEventListener('click', (e) => {
    if (e.target === petModal) petModal.classList.remove('active');
    if (e.target === cartDrawer) cartDrawer.classList.remove('active');
  });

  // 7. Interactive EMI Calculator Logic
  const emiSlider = document.getElementById('emi-budget-slider');
  const emiBudgetDisplay = document.getElementById('emi-budget-display');
  const emiMonthlyAmount = document.getElementById('emi-monthly-amount');
  const tenurePills = document.querySelectorAll('.tenure-pill');
  const applyEmiBtn = document.getElementById('btn-apply-emi');

  let selectedTenure = 6;

  function updateEmiCalculation() {
    if (!emiSlider) return;
    const budget = parseInt(emiSlider.value, 10);
    if (emiBudgetDisplay) {
      emiBudgetDisplay.textContent = `₹${budget.toLocaleString('en-IN')}`;
    }
    const monthlyEmi = Math.round(budget / selectedTenure);
    if (emiMonthlyAmount) {
      emiMonthlyAmount.textContent = `₹${monthlyEmi.toLocaleString('en-IN')} / month`;
    }
  }

  if (emiSlider) {
    emiSlider.addEventListener('input', updateEmiCalculation);
  }

  tenurePills.forEach(pill => {
    pill.addEventListener('click', () => {
      tenurePills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      selectedTenure = parseInt(pill.dataset.months, 10);
      updateEmiCalculation();
    });
  });

  if (applyEmiBtn) {
    applyEmiBtn.addEventListener('click', () => {
      const budget = emiSlider ? parseInt(emiSlider.value, 10) : 20000;
      const monthlyEmi = Math.round(budget / selectedTenure);
      const city = document.getElementById('current-city-label')?.textContent || 'India';
      const msg = encodeURIComponent(`Hi GoodFurs India! I want to apply for 0% Downpayment Puppy EMI for a budget of ₹${budget.toLocaleString('en-IN')} over ${selectedTenure} months (~₹${monthlyEmi.toLocaleString('en-IN')}/mo) in ${city}. Please guide me on approval.`);
      window.open(`https://wa.me/918779692292?text=${msg}`, '_blank');
    });
  }

  // 8. Dynamic Grooming Pricing Engine (City, Town & Village Tier Multipliers)
  let currentGroomingTier = 'city'; // 'city' | 'town' | 'village'
  let currentPetSize = 'small';     // 'small' | 'medium' | 'large' | 'cat'

  const tierMultipliers = {
    city: 1.0,     // Metro cities (standard base)
    town: 0.85,    // Tier-2 / Towns (~15% discount)
    village: 0.75  // Rural / Village camps (~25% discount)
  };

  const sizeMultipliers = {
    small: 1.0,    // 0-10 kg
    medium: 1.25,  // 10-25 kg
    large: 1.5,    // 25+ kg
    cat: 0.95      // Cat / Kitten
  };

  function updateGroomingPrices() {
    const tierMult = tierMultipliers[currentGroomingTier] || 1.0;
    const sizeMult = sizeMultipliers[currentPetSize] || 1.0;

    const baseBath = 799;
    const baseStyling = 1499;
    const baseDeshedding = 1899;

    const finalBath = Math.round(baseBath * tierMult * sizeMult);
    const finalStyling = Math.round(baseStyling * tierMult * sizeMult);
    const finalDeshedding = Math.round(baseDeshedding * tierMult * sizeMult);

    const elBath = document.getElementById('price-bath');
    const elStyling = document.getElementById('price-styling');
    const elDeshedding = document.getElementById('price-deshedding');

    if (elBath) elBath.textContent = `₹${finalBath.toLocaleString('en-IN')}`;
    if (elStyling) elStyling.textContent = `₹${finalStyling.toLocaleString('en-IN')}`;
    if (elDeshedding) elDeshedding.textContent = `₹${finalDeshedding.toLocaleString('en-IN')}`;
  }

  // Tier Buttons Click
  const tierButtons = document.querySelectorAll('.tier-btn');
  tierButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      tierButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentGroomingTier = btn.dataset.tier;
      updateGroomingPrices();
    });
  });

  // Size Pills Click
  const sizePills = document.querySelectorAll('.size-pill');
  sizePills.forEach(pill => {
    pill.addEventListener('click', () => {
      sizePills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      currentPetSize = pill.dataset.size;
      updateGroomingPrices();
    });
  });

  // Global Book Grooming Helper
  window.bookGrooming = function(packageName) {
    const tierName = currentGroomingTier === 'city' ? 'Metro City' : (currentGroomingTier === 'town' ? 'Town/Tier-2' : 'Village/Rural');
    const sizeName = currentPetSize === 'cat' ? 'Cat/Kitten' : `${currentPetSize.toUpperCase()} Dog`;
    let priceText = '₹1,499';
    if (packageName.includes('Hydro-Bath')) priceText = document.getElementById('price-bath')?.textContent || '₹799';
    if (packageName.includes('Styling')) priceText = document.getElementById('price-styling')?.textContent || '₹1,499';
    if (packageName.includes('De-Shedding')) priceText = document.getElementById('price-deshedding')?.textContent || '₹1,899';

    const cityLabel = document.getElementById('current-city-label')?.textContent || 'India';
    const msg = encodeURIComponent(`Hi eatNtreat India! I want to book a Doorstep Grooming Van for "${packageName}" (${sizeName}, ${tierName} Rate: ${priceText}) in ${cityLabel}. Please confirm slot availability.`);
    window.open(`https://wa.me/918779692292?text=${msg}`, '_blank');
  };

  // 9. Search Bar Expandable Toggle
  const searchToggleBtn = document.getElementById('btn-search-modal-toggle');
  const searchExpandable = document.getElementById('gf-search-bar-expandable');
  const closeSearchBarBtn = document.getElementById('btn-close-search-bar');
  const globalSearchInput = document.getElementById('global-pet-search');

  if (searchToggleBtn && searchExpandable) {
    searchToggleBtn.addEventListener('click', () => {
      searchExpandable.classList.toggle('active');
      if (searchExpandable.classList.contains('active') && globalSearchInput) {
        globalSearchInput.focus();
      }
    });
  }
  if (closeSearchBarBtn && searchExpandable) {
    closeSearchBarBtn.addEventListener('click', () => {
      searchExpandable.classList.remove('active');
    });
  }

  // 10. Auth / Sign In Modal Controls (Exact Match to Image 2)
  const authModal = document.getElementById('auth-signin-modal');
  const openAuthBtn = document.getElementById('btn-open-auth-modal');
  const closeAuthBtn = document.getElementById('btn-close-auth-modal');

  window.openAuthModal = function() {
    if (authModal) authModal.classList.add('active');
  };

  window.closeAuthModal = function() {
    if (authModal) authModal.classList.remove('active');
  };

  if (openAuthBtn) openAuthBtn.addEventListener('click', window.openAuthModal);
  if (closeAuthBtn) closeAuthBtn.addEventListener('click', window.closeAuthModal);
  if (authModal) {
    authModal.addEventListener('click', (e) => {
      if (e.target === authModal) window.closeAuthModal();
    });
  }

  // Auth Mode State (Sign In vs Register)
  let isRegisterMode = false;

  window.toggleAuthMode = function() {
    isRegisterMode = !isRegisterMode;
    const title = document.getElementById('auth-modal-title');
    const subtitle = document.getElementById('auth-modal-subtitle');
    const submitBtn = document.getElementById('btn-auth-submit');
    const switchText = document.getElementById('auth-switch-text');
    const switchLink = document.getElementById('auth-switch-link');

    if (isRegisterMode) {
      if (title) title.textContent = 'Register';
      if (subtitle) subtitle.textContent = 'Create your eatNtreat account in seconds';
      if (submitBtn) submitBtn.textContent = 'Create Account';
      if (switchText) switchText.textContent = 'Already have an account?';
      if (switchLink) switchLink.textContent = 'Sign In';
    } else {
      if (title) title.textContent = 'Sign In';
      if (subtitle) subtitle.textContent = 'Get started with eatNtreat now by signing in';
      if (submitBtn) submitBtn.textContent = 'Sign In';
      if (switchText) switchText.textContent = "Don't have an account?";
      if (switchLink) switchLink.textContent = 'Register Now';
    }
  };

  window.handleAuthSubmit = function(e) {
    e.preventDefault();
    const email = document.getElementById('auth-email')?.value || 'Pet Parent';
    const action = isRegisterMode ? 'Account created successfully!' : 'Signed in successfully!';
    showToast(`🎉 Welcome to eatNtreat! ${action}`);
    if (typeof confetti === 'function') {
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
    }
    window.closeAuthModal();
    if (openAuthBtn) {
      openAuthBtn.style.background = '#ECFDF5';
      openAuthBtn.style.borderColor = '#10B981';
      openAuthBtn.style.color = '#10B981';
    }
  };

  window.handleGoogleSignIn = function() {
    showToast('✨ Signed in with Google! Welcome to eatNtreat.');
    if (typeof confetti === 'function') {
      confetti({ particleCount: 60, spread: 70, origin: { y: 0.6 } });
    }
    window.closeAuthModal();
    if (openAuthBtn) {
      openAuthBtn.style.background = '#ECFDF5';
      openAuthBtn.style.borderColor = '#10B981';
      openAuthBtn.style.color = '#10B981';
    }
  };

  window.handleForgotPassword = function() {
    const email = document.getElementById('auth-email')?.value;
    if (email) {
      showToast(`Password reset link sent to ${email}`);
    } else {
      showToast('Please enter your email above to reset password.');
    }
  };

  // 11. Sell a Pet Helper
  window.openSellPetModal = function() {
    const city = document.getElementById('current-city-label')?.textContent || 'India';
    const msg = encodeURIComponent(`Hi eatNtreat India! I am a verified ethical breeder / pet parent in ${city} and want to list puppies for sale on eatNtreat. Please share the breeder registration process.`);
    window.open(`https://wa.me/918779692292?text=${msg}`, '_blank');
  };

  // 12. Mobile Navigation Drawer Controls
  const mobileMenuBtn = document.getElementById('btn-mobile-menu');
  const mobileNavBackdrop = document.getElementById('mobile-nav-backdrop');
  const closeMobileNavBtn = document.getElementById('btn-close-mobile-nav');
  const mobileNavLinks = document.querySelectorAll('.mob-link');
  const mobileSearchInput = document.getElementById('mobile-pet-search');

  if (mobileMenuBtn && mobileNavBackdrop) {
    mobileMenuBtn.addEventListener('click', () => {
      mobileNavBackdrop.classList.add('active');
    });
  }

  function closeMobileNav() {
    if (mobileNavBackdrop) mobileNavBackdrop.classList.remove('active');
  }

  if (closeMobileNavBtn) closeMobileNavBtn.addEventListener('click', closeMobileNav);
  if (mobileNavBackdrop) {
    mobileNavBackdrop.addEventListener('click', (e) => {
      if (e.target === mobileNavBackdrop) closeMobileNav();
    });
  }
  mobileNavLinks.forEach(link => {
    link.addEventListener('click', closeMobileNav);
  });

  if (mobileSearchInput) {
    mobileSearchInput.addEventListener('input', (e) => {
      const activeTab = document.querySelector('.filter-tab-pill.active')?.dataset.category || 'all';
      renderPuppiesGrid(activeTab, e.target.value);
    });
  }

  // Initial Calculation of Grooming
  updateGroomingPrices();
});
