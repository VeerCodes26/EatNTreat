/**
 * ============================================================================
 * KREO TYPING ARENA & MULTIPLAYER SQUAD RACE ENGINE
 * Real-time WPM • Accuracy • Streak Combos • Gen-Z Quote Packs • Confetti
 * ============================================================================
 */

class KreoTypingEngine {
  constructor() {
    this.wordsDisplay = document.getElementById('words-display');
    this.hiddenInput = document.getElementById('typing-hidden-input');
    this.arenaBox = document.querySelector('.typing-arena-box');

    this.wpmDisplay = document.getElementById('live-wpm');
    this.accDisplay = document.getElementById('live-acc');
    this.streakDisplay = document.getElementById('live-streak');
    this.cpsDisplay = document.getElementById('live-cps');
    this.raceTimerDisplay = document.getElementById('race-timer');

    this.racerUser = document.getElementById('racer-user');
    this.userWpmLive = document.getElementById('user-wpm-live');

    this.bot1Racer = document.getElementById('racer-bot1');
    this.bot2Racer = document.getElementById('racer-bot2');
    this.bot3Racer = document.getElementById('racer-bot3');

    this.currentCategory = 'genz';
    this.quotePacks = {
      genz: [
        "no cap this kreo keyboard with creamy lubed switches is pure butter on god",
        "main character energy unlocked with 160 words per minute speed flex",
        "skibidi rizz level one hundred typing at terminal velocity without errors",
        "gasket mount flex cuts and custom lubed linear stems hit different",
        "late night aesthetic coding session with neon violet underglow and lofi beats",
        "living rent free in the leaderboard while clacking on holy panda tactile switches"
      ],
      cyberpunk: [
        "neural link established overclocking typing reflexes to 1000hz polling rate",
        "the neon grid pulses with every tactile bottom out in the dark cyber city",
        "quantum keycaps encrypted with double shot pbt legend architecture",
        "synthetic audio synthesis mirroring mechanical acoustic resonance"
      ],
      code: [
        "const buildDreamKeyboard = (switches, lube) => ({ sound: 'creamy', wpm: 160 });",
        "function handleKeystroke(e) { trigger3DTravel(); playAcoustics(); }",
        "export async function synchronizeSquadRace(players) { return Promise.all(players); }",
        "const aura = document.querySelector('.keyboard-ambient-aura').style.filter;"
      ],
      quotes: [
        "creativity is intelligence having fun while mechanical switches sing",
        "the secret of getting ahead is getting started with every clean keystroke",
        "every master was once a beginner clacking away in the quiet of midnight"
      ]
    };

    this.text = '';
    this.charElements = [];
    this.currentIndex = 0;
    this.correctChars = 0;
    this.totalTyped = 0;
    this.streak = 0;
    this.maxStreak = 0;

    this.startTime = null;
    this.timerInterval = null;
    this.testDuration = 30; // seconds
    this.timeLeft = 30;
    this.isRunning = false;
    this.isFinished = false;

    this.botSpeeds = {
      bot1: { wpm: 138, progress: 0 },
      bot2: { wpm: 146, progress: 0 },
      bot3: { wpm: 124, progress: 0 }
    };

    this.init();
  }

  init() {
    this.bindEvents();
    this.loadNewQuote();
  }

  bindEvents() {
    // Mode pill buttons
    document.querySelectorAll('.mode-pill').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.mode-pill').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.currentCategory = btn.dataset.category;
        this.resetTest();
      });
    });

    // Clicking arena box focuses hidden input
    if (this.arenaBox) {
      this.arenaBox.addEventListener('click', () => {
        if (this.hiddenInput) this.hiddenInput.focus();
      });
    }

    // Input events
    if (this.hiddenInput) {
      this.hiddenInput.addEventListener('input', (e) => this.handleInput(e));
      this.hiddenInput.addEventListener('keydown', (e) => {
        if (e.key === 'Tab') {
          e.preventDefault();
          this.resetTest();
        }
      });
    }

    // Restart button
    const restartBtn = document.getElementById('btn-restart-test');
    if (restartBtn) {
      restartBtn.addEventListener('click', () => this.resetTest());
    }

    // Share card button
    const shareBtn = document.getElementById('btn-generate-share-card');
    if (shareBtn) {
      shareBtn.addEventListener('click', () => this.openShareModal());
    }

    // Launch Arena button in Home footer
    const launchArenaBtn = document.getElementById('btn-launch-arena');
    if (launchArenaBtn) {
      launchArenaBtn.addEventListener('click', () => {
        const typingPill = document.querySelector('.nav-pill[data-tab="typing"]');
        if (typingPill) typingPill.click();
        setTimeout(() => {
          if (this.hiddenInput) this.hiddenInput.focus();
        }, 300);
      });
    }

    // Modal Close
    const closeBtn = document.getElementById('btn-close-modal');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => {
        const modal = document.getElementById('social-card-modal');
        if (modal) modal.classList.remove('active');
      });
    }
  }

  loadNewQuote() {
    const list = this.quotePacks[this.currentCategory] || this.quotePacks.genz;
    this.text = list[Math.floor(Math.random() * list.length)];

    if (!this.wordsDisplay) return;
    this.wordsDisplay.innerHTML = '';
    this.charElements = [];

    const words = this.text.split(' ');
    words.forEach((wordStr, wIdx) => {
      const wordSpan = document.createElement('span');
      wordSpan.className = 'word';

      for (let i = 0; i < wordStr.length; i++) {
        const charSpan = document.createElement('span');
        charSpan.className = 'char';
        charSpan.textContent = wordStr[i];
        wordSpan.appendChild(charSpan);
        this.charElements.push(charSpan);
      }

      // Add space character span
      if (wIdx < words.length - 1) {
        const spaceSpan = document.createElement('span');
        spaceSpan.className = 'char';
        spaceSpan.textContent = ' ';
        wordSpan.appendChild(spaceSpan);
        this.charElements.push(spaceSpan);
      }

      this.wordsDisplay.appendChild(wordSpan);
    });

    if (this.charElements[0]) {
      this.charElements[0].classList.add('current');
    }
  }

  handleInput(e) {
    if (this.isFinished) return;
    const val = this.hiddenInput.value;
    if (!val) return;

    const typedChar = val[val.length - 1];

    if (!this.isRunning) {
      this.startTest();
    }

    const expectedChar = this.text[this.currentIndex];
    const targetEl = this.charElements[this.currentIndex];

    this.totalTyped++;

    if (typedChar === expectedChar) {
      if (targetEl) {
        targetEl.classList.remove('current', 'incorrect');
        targetEl.classList.add('correct');
      }
      this.correctChars++;
      this.streak++;
      this.maxStreak = Math.max(this.maxStreak, this.streak);

      // Streak celebration milestones
      if (this.streak === 50 || this.streak === 100) {
        if (typeof confetti === 'function') {
          confetti({ particleCount: 40, spread: 60, origin: { y: 0.8 } });
        }
      }
    } else {
      if (targetEl) {
        targetEl.classList.remove('current');
        targetEl.classList.add('incorrect');
      }
      this.streak = 0;
    }

    this.currentIndex++;

    if (this.currentIndex < this.charElements.length) {
      this.charElements[this.currentIndex].classList.add('current');
    } else {
      // Completed text
      this.finishTest();
    }

    this.updateStats();
  }

  startTest() {
    this.isRunning = true;
    this.startTime = Date.now();
    this.timeLeft = this.testDuration;

    this.timerInterval = setInterval(() => {
      this.timeLeft--;
      if (this.raceTimerDisplay) {
        this.raceTimerDisplay.textContent = `${this.timeLeft}s`;
      }

      this.updateBotRacers();
      this.updateStats();

      if (this.timeLeft <= 0) {
        this.finishTest();
      }
    }, 1000);
  }

  updateBotRacers() {
    const elapsedSec = (Date.now() - this.startTime) / 1000;
    const progressFactor = Math.min(1, elapsedSec / this.testDuration);

    if (this.bot1Racer) {
      const p1 = Math.min(92, progressFactor * 90 + (Math.sin(elapsedSec) * 2));
      this.bot1Racer.style.left = `${p1}%`;
    }
    if (this.bot2Racer) {
      const p2 = Math.min(94, progressFactor * 95 + (Math.cos(elapsedSec) * 2));
      this.bot2Racer.style.left = `${p2}%`;
    }
    if (this.bot3Racer) {
      const p3 = Math.min(88, progressFactor * 82);
      this.bot3Racer.style.left = `${p3}%`;
    }
  }

  updateStats() {
    if (!this.startTime) return;
    const elapsedMinutes = (Date.now() - this.startTime) / 60000;
    if (elapsedMinutes <= 0) return;

    const wpm = Math.round((this.correctChars / 5) / elapsedMinutes);
    const acc = this.totalTyped > 0 ? Math.round((this.correctChars / this.totalTyped) * 100) : 100;
    const cps = ((this.correctChars) / ((Date.now() - this.startTime) / 1000)).toFixed(1);

    if (this.wpmDisplay) this.wpmDisplay.textContent = wpm;
    if (this.accDisplay) this.accDisplay.textContent = `${acc}%`;
    if (this.streakDisplay) this.streakDisplay.textContent = `${this.streak}x 🔥`;
    if (this.cpsDisplay) this.cpsDisplay.textContent = cps;
    if (this.userWpmLive) this.userWpmLive.textContent = wpm;

    // Update player lane racer position
    if (this.racerUser && this.text.length > 0) {
      const userProgress = Math.min(94, (this.currentIndex / this.text.length) * 94);
      this.racerUser.style.left = `${userProgress}%`;
    }

    // Update community table
    const tableWpm = document.getElementById('table-user-wpm');
    const tableAcc = document.getElementById('table-user-acc');
    if (tableWpm) tableWpm.textContent = `${wpm} WPM`;
    if (tableAcc) tableAcc.textContent = `${acc}%`;
  }

  finishTest() {
    this.isRunning = false;
    this.isFinished = true;
    clearInterval(this.timerInterval);

    if (typeof confetti === 'function') {
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 }
      });
    }

    setTimeout(() => {
      this.openShareModal();
    }, 600);
  }

  resetTest() {
    clearInterval(this.timerInterval);
    this.isRunning = false;
    this.isFinished = false;
    this.currentIndex = 0;
    this.correctChars = 0;
    this.totalTyped = 0;
    this.streak = 0;
    this.startTime = null;
    this.timeLeft = this.testDuration;

    if (this.hiddenInput) {
      this.hiddenInput.value = '';
      this.hiddenInput.focus();
    }

    if (this.raceTimerDisplay) this.raceTimerDisplay.textContent = `${this.testDuration}s`;
    if (this.wpmDisplay) this.wpmDisplay.textContent = '0';
    if (this.accDisplay) this.accDisplay.textContent = '100%';
    if (this.streakDisplay) this.streakDisplay.textContent = '0x 🔥';
    if (this.cpsDisplay) this.cpsDisplay.textContent = '0.0';
    if (this.userWpmLive) this.userWpmLive.textContent = '0';

    if (this.racerUser) this.racerUser.style.left = '0%';
    if (this.bot1Racer) this.bot1Racer.style.left = '0%';
    if (this.bot2Racer) this.bot2Racer.style.left = '0%';
    if (this.bot3Racer) this.bot3Racer.style.left = '0%';

    this.loadNewQuote();
  }

  openShareModal() {
    const modal = document.getElementById('social-card-modal');
    if (!modal) return;

    const wpmVal = this.wpmDisplay ? this.wpmDisplay.textContent : '142';
    const accVal = this.accDisplay ? this.accDisplay.textContent : '99.2%';

    const cardWpm = document.getElementById('card-wpm-val');
    const cardAcc = document.getElementById('card-acc-val');
    const cardStreak = document.getElementById('card-streak-val');
    const cardSwitch = document.getElementById('card-switch-val');

    if (cardWpm) cardWpm.textContent = wpmVal === '0' ? '142' : wpmVal;
    if (cardAcc) cardAcc.textContent = accVal;
    if (cardStreak) cardStreak.textContent = `${Math.max(12, this.maxStreak)} Streak`;
    if (cardSwitch && window.kreoAudio) {
      const switchNames = {
        creamy: 'Creamy Butter (Lubed)',
        thocky: 'Holy Panda Thock',
        clicky: 'Crisp Blue Snap',
        silent: 'Silent Velvet ASMR',
        synth: '8-Bit Cyber Synth'
      };
      cardSwitch.textContent = switchNames[window.kreoAudio.currentProfile] || 'Creamy Butter';
    }

    modal.classList.add('active');
  }
}

window.kreoTyping = new KreoTypingEngine();
