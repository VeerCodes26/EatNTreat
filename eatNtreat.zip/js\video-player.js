/**
 * ============================================================================
 * KREO VIDEO STUDIO & AMBIENT CINEMA ENGINE
 * Integrated 4K Video Player • PiP • Drag-and-Drop Custom Video • Backdrop Sync
 * ============================================================================
 */

class KreoVideoEngine {
  constructor() {
    this.ambientVideo = document.getElementById('bg-video');
    this.studioVideo = document.getElementById('studio-main-video');
    this.playBtn = document.getElementById('btn-video-play');
    this.centerPlayBtn = document.getElementById('btn-center-play');
    this.muteBtn = document.getElementById('btn-video-mute');
    this.volSlider = document.getElementById('video-volume-slider');
    this.progressWrap = document.getElementById('video-progress-wrap');
    this.progressFill = document.getElementById('video-progress-fill');
    this.timeDisplay = document.getElementById('video-time-display');
    this.fullscreenBtn = document.getElementById('btn-video-fullscreen');
    this.pipBtn = document.getElementById('btn-pip-toggle');
    this.setBackdropBtn = document.getElementById('btn-set-backdrop');

    this.dropzone = document.getElementById('video-dropzone');
    this.fileInput = document.getElementById('custom-video-file-input');
    this.browseBtn = document.getElementById('btn-browse-video');

    this.toggleAmbient = document.getElementById('toggle-ambient-video');
    this.toggleBlur = document.getElementById('toggle-video-blur');
    this.opacitySlider = document.getElementById('slider-video-opacity');

    this.init();
  }

  init() {
    this.bindPlayerEvents();
    this.bindCustomVideoUpload();
    this.bindAmbientSettings();
  }

  bindPlayerEvents() {
    if (!this.studioVideo) return;

    const togglePlay = () => {
      if (this.studioVideo.paused) {
        this.studioVideo.play();
        this.updatePlayIcons(true);
      } else {
        this.studioVideo.pause();
        this.updatePlayIcons(false);
      }
    };

    if (this.playBtn) this.playBtn.addEventListener('click', togglePlay);
    if (this.centerPlayBtn) this.centerPlayBtn.addEventListener('click', togglePlay);

    // Update Progress
    this.studioVideo.addEventListener('timeupdate', () => {
      if (!this.studioVideo.duration) return;
      const pct = (this.studioVideo.currentTime / this.studioVideo.duration) * 100;
      if (this.progressFill) this.progressFill.style.width = `${pct}%`;

      if (this.timeDisplay) {
        const cur = this.formatTime(this.studioVideo.currentTime);
        const dur = this.formatTime(this.studioVideo.duration);
        this.timeDisplay.textContent = `${cur} / ${dur}`;
      }
    });

    // Seeking on click
    if (this.progressWrap) {
      this.progressWrap.addEventListener('click', (e) => {
        const rect = this.progressWrap.getBoundingClientRect();
        const pos = (e.clientX - rect.left) / rect.width;
        this.studioVideo.currentTime = pos * this.studioVideo.duration;
      });
    }

    // Volume & Mute
    if (this.muteBtn) {
      this.muteBtn.addEventListener('click', () => {
        this.studioVideo.muted = !this.studioVideo.muted;
        const icon = document.getElementById('video-mute-icon');
        if (icon) {
          icon.setAttribute('data-lucide', this.studioVideo.muted ? 'volume-x' : 'volume-2');
          if (window.lucide) window.lucide.createIcons();
        }
      });
    }

    if (this.volSlider) {
      this.volSlider.addEventListener('input', (e) => {
        this.studioVideo.volume = parseFloat(e.target.value);
        this.studioVideo.muted = false;
      });
    }

    // Fullscreen
    if (this.fullscreenBtn) {
      this.fullscreenBtn.addEventListener('click', () => {
        const screenContainer = document.getElementById('video-screen-container');
        if (screenContainer) {
          if (!document.fullscreenElement) {
            screenContainer.requestFullscreen().catch(err => console.log(err));
          } else {
            document.exitFullscreen();
          }
        }
      });
    }

    // PiP
    if (this.pipBtn) {
      this.pipBtn.addEventListener('click', async () => {
        try {
          if (document.pictureInPictureElement) {
            await document.exitPictureInPicture();
          } else {
            await this.studioVideo.requestPictureInPicture();
          }
        } catch (err) {
          console.warn("PiP not available:", err);
        }
      });
    }

    // Apply Studio Video to Ambient Backdrop
    if (this.setBackdropBtn) {
      this.setBackdropBtn.addEventListener('click', () => {
        if (this.ambientVideo && this.studioVideo) {
          this.ambientVideo.src = this.studioVideo.currentSrc || this.studioVideo.src;
          this.ambientVideo.play().catch(e => console.log(e));
          
          const origText = this.setBackdropBtn.innerHTML;
          this.setBackdropBtn.innerHTML = '<i data-lucide="check"></i> Backdrop Synced!';
          if (window.lucide) window.lucide.createIcons();
          setTimeout(() => {
            this.setBackdropBtn.innerHTML = origText;
            if (window.lucide) window.lucide.createIcons();
          }, 2000);
        }
      });
    }
  }

  updatePlayIcons(isPlaying) {
    const mainIcon = document.getElementById('video-btn-icon');
    const centerIcon = document.getElementById('center-play-icon');

    if (mainIcon) mainIcon.setAttribute('data-lucide', isPlaying ? 'pause' : 'play');
    if (centerIcon) centerIcon.setAttribute('data-lucide', isPlaying ? 'pause' : 'play');
    if (window.lucide) window.lucide.createIcons();

    if (this.centerPlayBtn) {
      this.centerPlayBtn.style.opacity = isPlaying ? '0.2' : '1';
    }
  }

  formatTime(seconds) {
    if (isNaN(seconds)) return '00:00';
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  }

  bindCustomVideoUpload() {
    if (!this.dropzone || !this.fileInput) return;

    if (this.browseBtn) {
      this.browseBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.fileInput.click();
      });
    }

    this.dropzone.addEventListener('click', () => {
      this.fileInput.click();
    });

    const handleFile = (file) => {
      if (!file || !file.type.startsWith('video/')) {
        alert("Please select a valid video file (.mp4, .webm).");
        return;
      }

      const fileUrl = URL.createObjectURL(file);
      
      // Update Studio Video
      if (this.studioVideo) {
        this.studioVideo.src = fileUrl;
        this.studioVideo.play();
        this.updatePlayIcons(true);
      }

      // Update Ambient Backdrop
      if (this.ambientVideo) {
        this.ambientVideo.src = fileUrl;
        this.ambientVideo.play().catch(e => console.log(e));
      }

      const nameDisp = document.getElementById('video-display-name');
      if (nameDisp) nameDisp.textContent = `Custom Video: ${file.name}`;
    };

    this.fileInput.addEventListener('change', (e) => {
      if (e.target.files && e.target.files[0]) {
        handleFile(e.target.files[0]);
      }
    });

    // Drag and Drop
    ['dragenter', 'dragover'].forEach(eventName => {
      this.dropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.dropzone.classList.add('dragover');
      });
    });

    ['dragleave', 'drop'].forEach(eventName => {
      this.dropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.dropzone.classList.remove('dragover');
      });
    });

    this.dropzone.addEventListener('drop', (e) => {
      const dt = e.dataTransfer;
      const files = dt.files;
      if (files && files[0]) {
        handleFile(files[0]);
      }
    });
  }

  bindAmbientSettings() {
    if (this.toggleAmbient) {
      this.toggleAmbient.addEventListener('change', (e) => {
        const container = document.getElementById('ambient-backdrop-container');
        if (container) container.style.display = e.target.checked ? 'block' : 'none';
      });
    }

    if (this.toggleBlur) {
      this.toggleBlur.addEventListener('change', (e) => {
        if (this.ambientVideo) {
          this.ambientVideo.style.filter = e.target.checked ? 'blur(28px) saturate(1.4)' : 'none';
        }
      });
    }

    if (this.opacitySlider) {
      this.opacitySlider.addEventListener('input', (e) => {
        const val = e.target.value;
        const valDisp = document.getElementById('val-video-opacity');
        if (valDisp) valDisp.textContent = `${val}%`;
        if (this.ambientVideo) {
          this.ambientVideo.style.opacity = (val / 100).toString();
        }
      });
    }
  }
}

window.kreoVideo = new KreoVideoEngine();
