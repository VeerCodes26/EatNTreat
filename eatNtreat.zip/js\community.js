/**
 * ============================================================================
 * KREO COMMUNITY, SQUAD & SOCIAL SHARING ENGINE
 * Live Activity Feed • Creator Showcase • Social Story Flex Card • Settings
 * ============================================================================
 */

class KreoCommunityEngine {
  constructor() {
    this.init();
  }

  init() {
    this.bindSettingsDrawer();
    this.bindSocialCardActions();
    this.bindLiveRaceQuickJoin();
    this.bindGiftLootBox();
    this.startDynamicFeedUpdates();
  }

  bindSettingsDrawer() {
    const settingsBtn = document.getElementById('btn-settings');
    const drawerModal = document.getElementById('settings-drawer-modal');
    const closeBtn = document.getElementById('btn-close-settings');

    if (settingsBtn && drawerModal) {
      settingsBtn.addEventListener('click', () => {
        drawerModal.classList.add('active');
      });
    }

    if (closeBtn && drawerModal) {
      closeBtn.addEventListener('click', () => {
        drawerModal.classList.remove('active');
      });
    }

    // OS Switcher (Mac vs Win)
    const btnMac = document.getElementById('btn-os-mac');
    const btnWin = document.getElementById('btn-os-win');

    if (btnMac && btnWin) {
      btnMac.addEventListener('click', () => {
        btnMac.classList.add('active');
        btnWin.classList.remove('active');
        if (window.kreoKeyboard) {
          window.kreoKeyboard.osMode = 'mac';
          window.kreoKeyboard.renderKeyboard();
        }
      });

      btnWin.addEventListener('click', () => {
        btnWin.classList.add('active');
        btnMac.classList.remove('active');
        if (window.kreoKeyboard) {
          window.kreoKeyboard.osMode = 'win';
          window.kreoKeyboard.renderKeyboard();
        }
      });
    }
  }

  bindSocialCardActions() {
    const copyBtn = document.getElementById('btn-copy-card');
    const tweetBtn = document.getElementById('btn-tweet-flex');

    if (copyBtn) {
      copyBtn.addEventListener('click', () => {
        const originalText = copyBtn.innerHTML;
        copyBtn.innerHTML = '<i data-lucide="check"></i> Copied to Clipboard!';
        if (window.lucide) window.lucide.createIcons();

        // Copy text summary to clipboard
        const wpm = document.getElementById('card-wpm-val')?.textContent || '142';
        const acc = document.getElementById('card-acc-val')?.textContent || '99.2%';
        const textToCopy = `⚡ Just clocked ${wpm} WPM with ${acc} accuracy on the Kreo Hive 96% Mechanical Studio! 🔥 Check it out: kreo.tech/vibe`;
        
        if (navigator.clipboard) {
          navigator.clipboard.writeText(textToCopy);
        }

        setTimeout(() => {
          copyBtn.innerHTML = originalText;
          if (window.lucide) window.lucide.createIcons();
        }, 2000);
      });
    }

    if (tweetBtn) {
      tweetBtn.addEventListener('click', () => {
        const wpm = document.getElementById('card-wpm-val')?.textContent || '142';
        const text = encodeURIComponent(`Just hit ${wpm} WPM on my Kreo 96% mechanical keyboard! 🧈✨ #MechanicalKeyboards #KreoVibe #TypingSpeed`);
        window.open(`https://twitter.com/intent/tweet?text=${text}`, '_blank');
      });
    }
  }

  bindLiveRaceQuickJoin() {
    const joinBtn = document.getElementById('btn-join-squad-race');
    if (joinBtn) {
      joinBtn.addEventListener('click', () => {
        const typingPill = document.querySelector('.nav-pill[data-tab="typing"]');
        if (typingPill) typingPill.click();
        if (window.kreoTyping) {
          window.kreoTyping.resetTest();
        }
      });
    }
  }

  bindGiftLootBox() {
    const giftBtn = document.getElementById('btn-gift');
    if (giftBtn) {
      giftBtn.addEventListener('click', () => {
        if (typeof confetti === 'function') {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.2 }
          });
        }
        alert("🎁 DAILY GEN-Z LOOT UNLOCKED!\nYou received: [Exclusive Cyber Violet Holo Keycap Badge] + 500 Vibe XP!");
      });
    }
  }

  startDynamicFeedUpdates() {
    const feed = document.getElementById('ticker-feed');
    if (!feed) return;

    const mockUpdates = [
      "⚡ <strong>Liam_X</strong> hit 168 WPM on Crisp Blue Clickies!",
      "💜 <strong>Sophie_Vibes</strong> claimed the Daily Mechanical Loot Box!",
      "🧈 <strong>Alex.rs</strong> switched to Creamy Butter Lubed Linear!",
      "🎧 <strong>2,510 gamers</strong> currently active on Kreo 3D Studio!"
    ];

    let index = 0;
    setInterval(() => {
      const newItem = document.createElement('div');
      newItem.className = 'ticker-item';
      newItem.innerHTML = mockUpdates[index % mockUpdates.length];
      feed.appendChild(newItem);
      index++;

      // Keep clean size
      if (feed.children.length > 8) {
        feed.removeChild(feed.children[0]);
      }
    }, 8000);
  }
}

window.kreoCommunity = new KreoCommunityEngine();
