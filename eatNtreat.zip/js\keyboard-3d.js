/**
 * ============================================================================
 * KREO 3D KEYBOARD ENGINE & HARDWARE EVENT BINDINGS
 * Exact 96% / 1800-Compact Layout • 3D Key Travel • 360° Orbit Drag • Sound Cascade
 * ============================================================================
 */

class KreoKeyboard3D {
  constructor() {
    this.container = document.getElementById('keyboard-keys-container');
    this.chassis = document.getElementById('keyboard-chassis');
    this.wrapper = document.getElementById('keyboard-3d-wrapper');
    this.aura = document.getElementById('keyboard-ambient-aura');
    this.canvas = document.getElementById('keystroke-canvas');
    this.ctx = this.canvas ? this.canvas.getContext('2d') : null;
    
    this.rotaryKnob = document.getElementById('rotary-knob');
    this.knobRotor = this.rotaryKnob ? this.rotaryKnob.querySelector('.knob-rotor') : null;
    this.knobRotation = 0;

    this.tiltEnabled = true;
    this.isDraggingOrbit = false;
    this.orbitRotationX = 16;
    this.orbitRotationY = -4;
    this.lastMouseX = 0;
    this.lastMouseY = 0;
    this.autoSpinning = false;

    this.activeRgbMode = 'violet-glow';
    this.activeRgbColor = '#8B5CF6';
    this.rgbBrightness = 0.9;
    this.osMode = 'mac';

    this.particles = [];
    this.keyMap = new Map();

    // 96% (1800-compact) Layout Definition
    this.layout = [
      // Row 1: Function Row + Navigation + Knob
      [
        { code: 'Escape', key: 'Esc', theme: 'purple', w: 1 },
        { code: 'F1', key: 'F1', theme: 'black', w: 1 },
        { code: 'F2', key: 'F2', theme: 'black', w: 1 },
        { code: 'F3', key: 'F3', theme: 'black', w: 1 },
        { code: 'F4', key: 'F4', theme: 'black', w: 1 },
        { code: 'F5', key: 'F5', theme: 'purple', w: 1 },
        { code: 'F6', key: 'F6', theme: 'purple', w: 1 },
        { code: 'F7', key: 'F7', theme: 'purple', w: 1 },
        { code: 'F8', key: 'F8', theme: 'purple', w: 1 },
        { code: 'F9', key: 'F9', theme: 'black', w: 1 },
        { code: 'F10', key: 'F10', theme: 'black', w: 1 },
        { code: 'F11', key: 'F11', theme: 'black', w: 1 },
        { code: 'F12', key: 'F12', theme: 'purple', w: 1 },
        { code: 'PrintScreen', key: 'Prtsc', theme: 'purple', w: 1 },
        { code: 'Delete', key: 'Del', theme: 'purple', w: 1 },
        { code: 'Home', key: 'Home', theme: 'purple', w: 1 },
        { code: 'PageUp', key: 'PgUp', theme: 'purple', w: 1 },
        { code: 'PageDown', key: 'PgDn', theme: 'purple', w: 1 },
        { code: 'KnobSlot', key: '', type: 'knob-spacer', w: 1.2 }
      ],
      // Row 2: Number / Symbol Row + Numpad Top
      [
        { code: 'Backquote', key: '~', sub: '`', theme: 'black', w: 1 },
        { code: 'Digit1', key: '!', sub: '1', theme: 'black', w: 1 },
        { code: 'Digit2', key: '@', sub: '2', theme: 'black', w: 1 },
        { code: 'Digit3', key: '#', sub: '3', theme: 'black', w: 1 },
        { code: 'Digit4', key: '$', sub: '4', theme: 'black', w: 1 },
        { code: 'Digit5', key: '%', sub: '5', theme: 'black', w: 1 },
        { code: 'Digit6', key: '^', sub: '6', theme: 'black', w: 1 },
        { code: 'Digit7', key: '&', sub: '7', theme: 'black', w: 1 },
        { code: 'Digit8', key: '*', sub: '8', theme: 'black', w: 1 },
        { code: 'Digit9', key: '(', sub: '9', theme: 'black', w: 1 },
        { code: 'Digit0', key: ')', sub: '0', theme: 'black', w: 1 },
        { code: 'Minus', key: '_', sub: '-', theme: 'black', w: 1 },
        { code: 'Equal', key: '+', sub: '=', theme: 'black', w: 1 },
        { code: 'Backspace', key: '← Back', theme: 'purple', w: 2 },
        { code: 'NumLock', key: 'Num', theme: 'purple', w: 1 },
        { code: 'NumpadDivide', key: '/', theme: 'purple', w: 1 },
        { code: 'NumpadMultiply', key: '*', theme: 'purple', w: 1 },
        { code: 'NumpadSubtract', key: '-', theme: 'purple', w: 1 }
      ],
      // Row 3: QWERTY + Numpad Middle
      [
        { code: 'Tab', key: 'Tabs', theme: 'purple', w: 1.5 },
        { code: 'KeyQ', key: 'Q', theme: 'black', w: 1 },
        { code: 'KeyW', key: 'W', theme: 'black', w: 1 },
        { code: 'KeyE', key: 'E', theme: 'black', w: 1 },
        { code: 'KeyR', key: 'R', theme: 'black', w: 1 },
        { code: 'KeyT', key: 'T', theme: 'black', w: 1 },
        { code: 'KeyY', key: 'Y', theme: 'black', w: 1 },
        { code: 'KeyU', key: 'U', theme: 'black', w: 1 },
        { code: 'KeyI', key: 'I', theme: 'black', w: 1 },
        { code: 'KeyO', key: 'O', theme: 'black', w: 1 },
        { code: 'KeyP', key: 'P', theme: 'black', w: 1 },
        { code: 'BracketLeft', key: '{', sub: '[', theme: 'black', w: 1 },
        { code: 'BracketRight', key: '}', sub: ']', theme: 'black', w: 1 },
        { code: 'Backslash', key: '|', sub: '\\', theme: 'black', w: 1.5 },
        { code: 'Numpad7', key: '7', sub: 'Home', theme: 'black', w: 1 },
        { code: 'Numpad8', key: '8', sub: '▲', theme: 'black', w: 1 },
        { code: 'Numpad9', key: '9', sub: 'PgUp', theme: 'black', w: 1 },
        { code: 'NumpadAdd', key: '+', theme: 'purple', w: 1 }
      ],
      // Row 4: Home Row (ASDF) + Numpad Core
      [
        { code: 'CapsLock', key: 'CapsLock', theme: 'purple', w: 1.75 },
        { code: 'KeyA', key: 'A', theme: 'black', w: 1 },
        { code: 'KeyS', key: 'S', theme: 'black', w: 1 },
        { code: 'KeyD', key: 'D', theme: 'black', w: 1 },
        { code: 'KeyF', key: 'F', theme: 'black', w: 1 },
        { code: 'KeyG', key: 'G', theme: 'black', w: 1 },
        { code: 'KeyH', key: 'H', theme: 'black', w: 1 },
        { code: 'KeyJ', key: 'J', theme: 'black', w: 1 },
        { code: 'KeyK', key: 'K', theme: 'black', w: 1 },
        { code: 'KeyL', key: 'L', theme: 'black', w: 1 },
        { code: 'Semicolon', key: ':', sub: ';', theme: 'black', w: 1 },
        { code: 'Quote', key: '"', sub: '\'', theme: 'black', w: 1 },
        { code: 'Enter', key: 'Enter ↵', theme: 'purple', w: 2.25 },
        { code: 'Numpad4', key: '4', sub: '◄', theme: 'black', w: 1 },
        { code: 'Numpad5', key: '5', theme: 'black', w: 1 },
        { code: 'Numpad6', key: '6', sub: '►', theme: 'black', w: 1 },
        { code: 'NumpadEnter', key: '↵', theme: 'purple', w: 1 }
      ],
      // Row 5: Shift Row + Compact Arrows + Numpad Bottom
      [
        { code: 'ShiftLeft', key: '⇧ Shift', theme: 'purple', w: 2.25 },
        { code: 'KeyZ', key: 'Z', theme: 'black', w: 1 },
        { code: 'KeyX', key: 'X', theme: 'black', w: 1 },
        { code: 'KeyC', key: 'C', theme: 'black', w: 1 },
        { code: 'KeyV', key: 'V', theme: 'black', w: 1 },
        { code: 'KeyB', key: 'B', theme: 'black', w: 1 },
        { code: 'KeyN', key: 'N', theme: 'black', w: 1 },
        { code: 'KeyM', key: 'M', theme: 'black', w: 1 },
        { code: 'Comma', key: '<', sub: ',', theme: 'black', w: 1 },
        { code: 'Period', key: '>', sub: '.', theme: 'black', w: 1 },
        { code: 'Slash', key: '?', sub: '/', theme: 'black', w: 1 },
        { code: 'ShiftRight', key: '⇧', theme: 'purple', w: 1.75 },
        { code: 'ArrowUp', key: '▲', theme: 'purple', w: 1 },
        { code: 'Numpad1', key: '1', sub: 'End', theme: 'black', w: 1 },
        { code: 'Numpad2', key: '2', sub: '▼', theme: 'black', w: 1 },
        { code: 'Numpad3', key: '3', sub: 'PgDn', theme: 'black', w: 1 },
        { code: 'NumpadEnter2', key: 'Enter', theme: 'purple', w: 1 }
      ],
      // Row 6: Bottom Mods + Spacebar + Arrows + Numpad 0/Del
      [
        { code: 'ControlLeft', key: 'Ctrl', theme: 'purple', w: 1.25 },
        { code: 'MetaLeft', key: 'Win', sub: 'Cmd', theme: 'purple', w: 1.25 },
        { code: 'AltLeft', key: 'Alt', sub: 'Opt', theme: 'purple', w: 1.25 },
        { code: 'Space', key: '', theme: 'black', w: 6.25, isSpace: true },
        { code: 'AltRight', key: 'Alt', theme: 'purple', w: 1 },
        { code: 'Fn', key: 'Fn', theme: 'purple', w: 1 },
        { code: 'ArrowLeft', key: '◄', theme: 'purple', w: 1 },
        { code: 'ArrowDown', key: '▼', theme: 'purple', w: 1 },
        { code: 'ArrowRight', key: '►', theme: 'purple', w: 1 },
        { code: 'Numpad0', key: '0', sub: 'Ins', theme: 'black', w: 2 },
        { code: 'NumpadDecimal', key: '.', sub: 'Del', theme: 'purple', w: 1 }
      ]
    ];

    this.init();
  }

  init() {
    this.renderKeyboard();
    this.bindEvents();
    this.setupOrbitAndTilt();
    this.setupRotaryKnob();
    this.initCanvas();
    this.startRgbAnimationLoop();
  }

  renderKeyboard() {
    if (!this.container) return;
    this.container.innerHTML = '';
    this.keyMap.clear();

    this.layout.forEach((row, rIdx) => {
      const rowEl = document.createElement('div');
      rowEl.className = 'key-row';
      rowEl.dataset.row = rIdx;

      row.forEach((k) => {
        if (k.type === 'knob-spacer') {
          const spacer = document.createElement('div');
          spacer.style.flex = k.w;
          spacer.style.pointerEvents = 'none';
          rowEl.appendChild(spacer);
          return;
        }

        const keyEl = document.createElement('div');
        keyEl.className = `key-cap theme-${k.theme}`;
        keyEl.dataset.code = k.code;
        keyEl.dataset.key = k.key;
        if (k.isSpace) keyEl.classList.add('key-w-space');
        else keyEl.style.flex = k.w;

        // Key Top Face
        const topEl = document.createElement('div');
        topEl.className = 'key-top';

        if (k.isSpace) {
          topEl.innerHTML = '<span class="space-line" style="width: 60px; height: 3px; background: rgba(255,255,255,0.4); border-radius: 2px;"></span>';
        } else {
          const primLegend = document.createElement('span');
          primLegend.className = 'key-primary-legend';
          primLegend.textContent = (this.osMode === 'mac' && k.sub && (k.key === 'Win' || k.key === 'Alt')) ? k.sub : k.key;

          topEl.appendChild(primLegend);

          if (k.sub && !k.isSpace && k.key !== 'Win' && k.key !== 'Alt') {
            const subLegend = document.createElement('span');
            subLegend.className = 'key-sub-legend';
            subLegend.textContent = k.sub;
            topEl.appendChild(subLegend);
          }
        }

        // 3D Side extrusion
        const sideEl = document.createElement('div');
        sideEl.className = 'key-side';

        // RGB LED Glow ring
        const ledGlow = document.createElement('div');
        ledGlow.className = 'key-led-glow';

        keyEl.appendChild(ledGlow);
        keyEl.appendChild(sideEl);
        keyEl.appendChild(topEl);

        // Click / Touch Listener
        keyEl.addEventListener('mousedown', (e) => {
          e.preventDefault();
          this.triggerKeyPress(k.code, k.key, k.isSpace, k.theme === 'purple', true);
        });

        rowEl.appendChild(keyEl);
        this.keyMap.set(k.code, keyEl);

        if (k.code === 'ControlLeft') this.keyMap.set('ControlRight', keyEl);
        if (k.code === 'MetaLeft') this.keyMap.set('MetaRight', keyEl);
        if (k.code === 'AltLeft') this.keyMap.set('AltRight', keyEl);
      });

      this.container.appendChild(rowEl);
    });
  }

  bindEvents() {
    // Hardware Keyboard Events
    window.addEventListener('keydown', (e) => {
      const isSpace = e.code === 'Space';
      const isMod = ['ControlLeft', 'ControlRight', 'AltLeft', 'AltRight', 'MetaLeft', 'MetaRight', 'ShiftLeft', 'ShiftRight', 'Tab', 'Enter', 'Backspace', 'Escape'].includes(e.code);

      this.triggerKeyPress(e.code, e.key, isSpace, isMod, false);

      // Status LEDs toggle
      if (e.code === 'CapsLock') {
        const capsLed = document.querySelector('.led-caps');
        if (capsLed) capsLed.classList.toggle('active', e.getModifierState('CapsLock'));
      }
      if (e.code === 'NumLock') {
        const numLed = document.querySelector('.led-num');
        if (numLed) numLed.classList.toggle('active', e.getModifierState('NumLock'));
      }
    });

    window.addEventListener('keyup', (e) => {
      const keyEl = this.keyMap.get(e.code);
      if (keyEl) {
        keyEl.classList.remove('is-pressed');
      }
    });

    window.addEventListener('mouseup', () => {
      this.keyMap.forEach(el => el.classList.remove('is-pressed'));
    });
  }

  triggerKeyPress(code, keyLabel, isSpace, isMod, fromMouse = false) {
    const keyEl = this.keyMap.get(code);

    if (keyEl) {
      keyEl.classList.add('is-pressed');
      if (fromMouse) {
        setTimeout(() => keyEl.classList.remove('is-pressed'), 120);
      }

      // Spark Particles
      const rect = keyEl.getBoundingClientRect();
      const wrapRect = this.wrapper ? this.wrapper.getBoundingClientRect() : rect;
      const x = rect.left + rect.width / 2 - wrapRect.left;
      const y = rect.top + rect.height / 2 - wrapRect.top;
      this.emitParticles(x, y, this.activeRgbColor);
    }

    // Audio Playback
    if (window.kreoAudio) {
      window.kreoAudio.playKey(code.charCodeAt(code.length - 1) || 65, isSpace, isMod);
    }

    // Update Live Pressed Key HUD
    const liveKey = document.getElementById('live-last-key');
    const liveCode = document.getElementById('live-last-code');
    if (liveKey) liveKey.textContent = (keyLabel === ' ' ? 'SPACE' : (keyLabel || code)).toUpperCase();
    if (liveCode) liveCode.textContent = `Code: ${code}`;
  }

  setupOrbitAndTilt() {
    if (!this.wrapper || !this.chassis) return;

    // Mouse Move Tilt
    this.wrapper.addEventListener('mousemove', (e) => {
      if (this.isDraggingOrbit) {
        const deltaX = e.clientX - this.lastMouseX;
        const deltaY = e.clientY - this.lastMouseY;
        this.orbitRotationY += deltaX * 0.4;
        this.orbitRotationX -= deltaY * 0.4;
        this.orbitRotationX = Math.max(-20, Math.min(65, this.orbitRotationX));
        this.lastMouseX = e.clientX;
        this.lastMouseY = e.clientY;
        this.chassis.style.transform = `rotateX(${this.orbitRotationX}deg) rotateY(${this.orbitRotationY}deg)`;
        return;
      }

      if (!this.tiltEnabled) return;
      const rect = this.wrapper.getBoundingClientRect();
      const x = e.clientX - rect.left - rect.width / 2;
      const y = e.clientY - rect.top - rect.height / 2;

      const tiltX = -(y / rect.height) * 16 + 14;
      const tiltY = (x / rect.width) * 16;

      this.chassis.style.transform = `rotateX(${tiltX}deg) rotateY(${tiltY}deg)`;
    });

    this.wrapper.addEventListener('mousedown', (e) => {
      if (e.target.closest('.key-cap') || e.target.closest('#rotary-knob')) return;
      this.isDraggingOrbit = true;
      this.lastMouseX = e.clientX;
      this.lastMouseY = e.clientY;
    });

    window.addEventListener('mouseup', () => {
      this.isDraggingOrbit = false;
    });
  }

  setCameraView(viewName) {
    if (!this.chassis) return;
    this.autoSpinning = false;
    if (viewName === 'iso') {
      this.orbitRotationX = 18;
      this.orbitRotationY = -4;
    } else if (viewName === 'front') {
      this.orbitRotationX = 8;
      this.orbitRotationY = 0;
    } else if (viewName === 'top') {
      this.orbitRotationX = 0;
      this.orbitRotationY = 0;
    } else if (viewName === 'spin') {
      this.autoSpinning = true;
      this.spinLoop();
      return;
    }
    this.chassis.style.transform = `rotateX(${this.orbitRotationX}deg) rotateY(${this.orbitRotationY}deg)`;
  }

  spinLoop() {
    if (!this.autoSpinning || !this.chassis) return;
    this.orbitRotationY += 0.8;
    this.chassis.style.transform = `rotateX(15deg) rotateY(${this.orbitRotationY}deg)`;
    requestAnimationFrame(() => this.spinLoop());
  }

  setupRotaryKnob() {
    if (!this.rotaryKnob || !this.knobRotor) return;

    const turnKnob = (delta) => {
      this.knobRotation += delta;
      this.knobRotor.style.transform = `rotate(${this.knobRotation}deg)`;

      if (window.kreoAudio) {
        window.kreoAudio.playKnobTick();
      }

      this.activeRgbColor = `hsl(${(Math.abs(this.knobRotation) * 2) % 360}, 85%, 60%)`;
      if (this.aura) this.aura.style.background = `radial-gradient(ellipse at center, ${this.activeRgbColor} 0%, rgba(139, 92, 246, 0) 70%)`;
    };

    this.rotaryKnob.addEventListener('wheel', (e) => {
      e.preventDefault();
      turnKnob(e.deltaY > 0 ? 15 : -15);
    });

    this.rotaryKnob.addEventListener('click', () => {
      turnKnob(30);
    });
  }

  playCascadeDemo() {
    if (window.kreoAudio) {
      window.kreoAudio.ensureAudio();
    }

    const demoKeys = ['KeyK', 'KeyR', 'KeyE', 'KeyO', 'Digit9', 'Digit6', 'Space'];
    demoKeys.forEach((kCode, idx) => {
      setTimeout(() => {
        const el = this.keyMap.get(kCode);
        const label = el ? el.dataset.key : kCode;
        this.triggerKeyPress(kCode, label, kCode === 'Space', false, true);
      }, idx * 160);
    });

    if (typeof confetti === 'function') {
      confetti({ particleCount: 60, spread: 70, origin: { y: 0.6 } });
    }
  }

  setRgbMode(mode) {
    this.activeRgbMode = mode;
  }

  setRgbColor(color) {
    this.activeRgbColor = color;
    document.documentElement.style.setProperty('--rgb-glow-color', color);
  }

  setBrightness(val) {
    this.rgbBrightness = val;
    document.documentElement.style.setProperty('--rgb-glow-intensity', val);
  }

  startRgbAnimationLoop() {
    let t = 0;

    const animateRgb = () => {
      t += 0.04;
      const keys = Array.from(this.keyMap.values());

      if (this.activeRgbMode === 'violet-glow') {
        const pulse = Math.sin(t) * 0.15 + 0.85;
        this.keyMap.forEach((el) => {
          const glow = el.querySelector('.key-led-glow');
          if (glow) glow.style.boxShadow = `0 0 10px rgba(139, 92, 246, ${0.4 * pulse * this.rgbBrightness})`;
        });
      } else if (this.activeRgbMode === 'cyber-wave') {
        keys.forEach((el, idx) => {
          const hue = (t * 50 + idx * 8) % 360;
          const glow = el.querySelector('.key-led-glow');
          if (glow) glow.style.boxShadow = `0 0 12px hsla(${hue}, 90%, 60%, ${0.6 * this.rgbBrightness})`;
        });
      } else if (this.activeRgbMode === 'matrix-rain') {
        keys.forEach((el, idx) => {
          const lum = Math.sin(t * 3 + idx * 0.4) > 0.6 ? 0.9 : 0.1;
          const glow = el.querySelector('.key-led-glow');
          if (glow) glow.style.boxShadow = `0 0 12px rgba(34, 197, 94, ${lum * this.rgbBrightness})`;
        });
      }

      requestAnimationFrame(animateRgb);
    };

    animateRgb();
  }

  initCanvas() {
    if (!this.canvas) return;
    const resize = () => {
      if (this.wrapper) {
        this.canvas.width = this.wrapper.clientWidth;
        this.canvas.height = this.wrapper.clientHeight;
      }
    };
    window.addEventListener('resize', resize);
    resize();
    this.renderParticleLoop();
  }

  emitParticles(x, y, color) {
    for (let i = 0; i < 8; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 4 + 1.5;
      this.particles.push({
        x: x,
        y: y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 1.5,
        size: Math.random() * 3 + 2,
        color: color || '#8B5CF6',
        alpha: 1,
        life: 1
      });
    }
  }

  renderParticleLoop() {
    if (!this.ctx || !this.canvas) return;
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.12;
      p.alpha -= 0.035;
      p.size = Math.max(0.1, p.size - 0.05);

      this.ctx.save();
      this.ctx.globalAlpha = Math.max(0, p.alpha);
      this.ctx.fillStyle = p.color;
      this.ctx.shadowBlur = 8;
      this.ctx.shadowColor = p.color;
      this.ctx.beginPath();
      this.ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      this.ctx.fill();
      this.ctx.restore();

      if (p.alpha <= 0) {
        this.particles.splice(i, 1);
      }
    }

    requestAnimationFrame(() => this.renderParticleLoop());
  }
}

// Global keyboard singleton
window.kreoKeyboard = new KreoKeyboard3D();
